<?php return array (
  'reposition_cover' => 'تغییر موقعیت پوشش',
);