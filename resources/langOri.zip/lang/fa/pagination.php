<?php return array (
  'previous' => '«قبلی',
  'next' => 'بعد &quot;',
);