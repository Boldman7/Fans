<?php return array (
  'password' => 'Şifreler en az altı karakter uzunluğunda ve onayı aynı olmalıdır.',
  'reset' => 'Şifreniz sıfırlandı!',
  'sent' => 'Biz şifre sıfırlama bağlantısı e-postalanacaktır var!',
  'token' => 'Bu parola sıfırlama simge geçersiz.',
  'user' => 'Biz bu e-posta adresine sahip bir kullanıcı bulamıyorum.',
);