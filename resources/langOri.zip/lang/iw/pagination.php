<?php return array (
  'previous' => '&quot; קודם',
  'next' => 'הבא »',
);