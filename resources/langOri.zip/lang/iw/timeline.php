<?php return array (
  'reposition_cover' => 'מיקום מחדש כיסוי',
);