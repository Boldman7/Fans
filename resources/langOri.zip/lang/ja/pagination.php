<?php return array (
  'previous' => '«前の',
  'next' => '次 &quot;',
);