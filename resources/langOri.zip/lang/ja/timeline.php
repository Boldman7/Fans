<?php return array (
  'reposition_cover' => 'カバーを再配置',
);