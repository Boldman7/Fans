<?php return array (
  'previous' => '«Precedente',
  'next' => 'Il prossimo &quot;',
);