<?php return array (
  'password' => 'Le password devono essere di almeno sei caratteri e abbinare la conferma.',
  'reset' => 'La tua password è stata resettata!',
  'sent' => 'Abbiamo una e-mail il tuo link di reimpostazione password!',
  'token' => 'Questo token reimpostazione della password non è valido.',
  'user' => 'Non possiamo trovare un utente con tale indirizzo e-mail.',
);