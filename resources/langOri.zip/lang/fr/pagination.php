<?php return array (
  'previous' => '&quot; Précédent',
  'next' => 'Prochain &quot;',
);