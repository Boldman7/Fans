<?php return array (
  'password' => 'Las contraseñas deben tener al menos seis caracteres y combinar la confirmación.',
  'reset' => '¡Tu contraseña ha sido restablecida!',
  'sent' => 'Hemos enviado por correo electrónico el enlace para restablecer la contraseña!',
  'token' => 'Esta señal de restablecimiento de contraseña no es válido.',
  'user' => 'No podemos encontrar un usuario con esa dirección de correo electrónico.',
);