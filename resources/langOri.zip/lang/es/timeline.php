<?php return array (
  'reposition_cover' => 'Volver a colocar la cubierta',
);