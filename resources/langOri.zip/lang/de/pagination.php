<?php return array (
  'previous' => '&quot; Bisherige',
  'next' => 'Nächster &quot;',
);