<?php return array (
  'reposition_cover' => 'repositionieren Abdeckung',
);