<?php return array (
  'reposition_cover' => 'Repositionner couvercle',
);