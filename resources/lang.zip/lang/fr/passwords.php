<?php return array (
  'password' => 'Les mots de passe doivent comporter au moins six caractères et correspondre à la confirmation.',
  'reset' => 'Votre mot de passe a été réinitialisé!',
  'sent' => 'Nous avons envoyé par courriel votre mot de passe lien de réinitialisation!',
  'token' => 'Ce jeton de réinitialisation de mot est invalide.',
  'user' => 'Nous ne pouvons pas trouver un utilisateur avec cette adresse e-mail.',
);