<?php return array (
  'reposition_cover' => 'riposizionare la copertura',
);