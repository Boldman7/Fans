<?php return array (
  'previous' => '«Önceki',
  'next' => 'Sonraki &quot;',
);