<?php return array (
  'reposition_cover' => 'kapağı yeniden konumlandırma',
);