<?php return array (
  'password' => 'Passwörter müssen mindestens sechs Zeichen lang sein und die Bestätigung entsprechen.',
  'reset' => 'Dein Passwort wurde zurück gesetzt!',
  'sent' => 'Wir haben per E-Mail Ihr Passwort-Reset-Link!',
  'token' => 'Dieses Passwort-Reset-Token ist ungültig.',
  'user' => 'Wir können keine Benutzer mit dieser E-Mail-Adresse zu finden.',
);