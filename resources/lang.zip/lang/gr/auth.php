<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2016/08/06 13:41:49
*************************************************************************/

return  [
  //==================================== Translations ====================================//
  'affiliate_code'            => 'Affiliate code',
  'already_have_an_account'   => 'Already have an account',
  'confirm_password'          => 'Confirm password',
  'dont_have_an_account_yet'  => 'Don\'t have an account yet?',
  'email_address'             => 'E-mail address',
  'enter_email_or_username'   => 'Enter E-mail or username',
  'forgot_password'           => 'forgot password',
  'get_started'               => 'get started',
  'login_failed'              => 'Invalid Login credentials.',
  'login_success'             => 'Login Success',
  'login_via_social_networks' => 'Login via social networks',
  'login_welcome_heading'     => 'Welcome back! Please login.',
  'reset_welcome_heading'     => 'Reset your password.',
  'name'                      => 'name',
  'password'                  => 'Password',
  'register'                  => 'Register',
  'login'                     => 'Login',
  'registered_verify_email'   => 'You have successfully registered!<br>Please verify your email before logging in.',
  'reset_password'            => 'Reset Password',
  'reset_your_password'       => 'Reset Your Password.',
  'select_gender'             => 'Select gender',
  'send_password_reset_link'  => 'Send Password Reset Link',
  'sign_in'                   => 'Sign In',
  'signin_to_dashboard'       => 'Sign in to Dashboard',
  'signup_to_dashboard'       => 'Sign up to Dashboard',
  'verify_email'              => 'Please verify your email.',
  'welcome_to'                => 'Welcome To',
  'subject'                   => 'Subject',
  'submit'                    => 'Submit',
  'email_verify'              => 'Please verify your email before logging in',
];
