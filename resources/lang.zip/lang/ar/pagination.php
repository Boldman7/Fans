<?php return array (
  'previous' => '«السابق',
  'next' => 'التالى &quot;',
);