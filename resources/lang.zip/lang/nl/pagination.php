<?php return array (
  'previous' => '«Vorige',
  'next' => 'Volgende »',
);