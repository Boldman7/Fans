<!-- main-section -->
<!-- <div class="main-content"> -->
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<div class="post-filters">
					{!! Theme::partial('usermenu-settings') !!}
				</div>
			</div>
			<div class="col-md-8">
				<div class="panel panel-default">
				
					<div class="panel-heading no-bg panel-settings">
						@include('flash::message')
						<h3 class="panel-title">
							Add Payment Method
						</h3>
					</div>
					<div class="panel-body nopadding">
						<div class="socialite-form">							
							<form method="POST" action="{{ url('/'.$username.'/settings/payment_detail/') }}">
								{{ csrf_field() }}
								
								<div class="row">
									<div class="col-md-6">
										<fieldset class="form-group required {{ $errors->has('name') ? ' has-error' : '' }}">
											{{ Form::label('name', trans('Name on Card')) }}
											{{ Form::text('card_name', Auth::user()->name, ['class' => 'form-control', 'placeholder' => trans('Name on Card')]) }}
											@if ($errors->has('name'))
											<span class="help-block">
												{{ $errors->first('name') }}
											</span>
											@endif
										</fieldset>
									</div>
								</div>

								<div class="row">
									<div class="col-md-6">
										<fieldset class="form-group">
											{{ Form::label('card_number', trans('Card Number')) }}
											{{ Form::text('card_number', Auth::user()->payment()->first()->card_number, array('class' => 'form-control', 'placeholder' => trans('Card Number'))) }}
										</fieldset>
									</div>
								</div>
								
								<div class="row">
									<div class="col-md-3">
										<fieldset class="form-group">
											{{ Form::label('exp_mm', trans('Expiration Month')) }}
											{{ Form::text('exp_mm', Auth::user()->payment()->first()->exp_mm, array('class' => 'form-control', 'placeholder' => trans('MM'))) }}
										</fieldset>
									</div>
									<div class="col-md-3">
										<fieldset class="form-group">
											{{ Form::label('exp_yyyy', trans('Expiration Year')) }}
											{{ Form::text('exp_yyyy', Auth::user()->payment()->first()->exp_yy, array('class' => 'form-control', 'placeholder' => trans('YYYY'))) }}
										</fieldset>
									</div>
									<div class="col-md-3">
										<fieldset class="form-group">
											{{ Form::label('cvv', trans('CVV')) }}
											{{ Form::text('cvv', Auth::user()->payment()->first()->cvv, array('class' => 'form-control', 'placeholder' => trans('CVV'))) }}
										</fieldset>
									</div>									
								</div>
								
								<div class="row">
									<div class="col-md-6">
										<fieldset class="form-group">
											{{ Form::label('address', trans('Billing Street Address')) }}
											{{ Form::text('address', Auth::user()->payment()->first()->address, ['class' => 'form-control', 'placeholder' => trans('Billing Street Address')]) }}
										</fieldset>
									</div>
									<div class="col-md-6">
										<fieldset class="form-group">
											{{ Form::label('city', trans('City')) }}
											{{ Form::text('city', Auth::user()->payment()->first()->city, ['class' => 'form-control', 'placeholder' => trans('City')]) }}
										</fieldset>
									</div>
								</div>

								<div class="row">
									<div class="col-md-6">
										<fieldset class="form-group">
											{{ Form::label('state', trans('State/Province')) }}
											{{ Form::text('state', Auth::user()->payment()->first()->state, ['class' => 'form-control', 'placeholder' => trans('State/Province')]) }}
										</fieldset>
									</div>
									<div class="col-md-6">
										<fieldset class="form-group">
											{{ Form::label('zip', trans('Zip/Postal Code')) }}
											{{ Form::text('zip', Auth::user()->payment()->first()->zip, ['class' => 'form-control', 'placeholder' => trans('Zip/Postal Code')]) }}
										</fieldset>
									</div>
								</div>
								
								<div class="row">
									<div class="col-md-10">
										<fieldset class="form-group">
											{{ Form::checkbox('content', 'Yes') }}
											{{ Form::label('content', trans('Yes, I am at least 18 years old and confirm use of my card for transactions.')) }}
										</fieldset>
									</div>
								</div>
									
									@if(Setting::get('custom_option1') != NULL || Setting::get('custom_option2') != NULL)
										<div class="row">
											@if(Setting::get('custom_option1') != NULL)
											<div class="col-md-6">
												<fieldset class="form-group">
													{{ Form::label('custom_option1', Setting::get('custom_option1')) }}
													{{ Form::text('custom_option1', Auth::user()->custom_option1, ['class' => 'form-control']) }}
												</fieldset>
											</div>
											@endif

											@if(Setting::get('custom_option2') != NULL)
											<div class="col-md-6">
												<fieldset class="form-group">
													{{ Form::label('custom_option2', Setting::get('custom_option2')) }}
													{{ Form::text('custom_option2', Auth::user()->custom_option2, ['class' => 'form-control']) }}
												</fieldset>
											</div>
											@endif
										</div>
									@endif

									@if(Setting::get('custom_option3') != NULL || Setting::get('custom_option4') != NULL)
										<div class="row">
											@if(Setting::get('custom_option3') != NULL)
											<div class="col-md-6">
												<fieldset class="form-group">
													{{ Form::label('custom_option3', Setting::get('custom_option3')) }}
													{{ Form::text('custom_option3', Auth::user()->custom_option3, ['class' => 'form-control']) }}
												</fieldset>
											</div>
											@endif

											@if(Setting::get('custom_option4') != NULL)
											<div class="col-md-6">
												<fieldset class="form-group">
													{{ Form::label('custom_option4', Setting::get('custom_option4')) }}
													{{ Form::text('custom_option4', Auth::user()->custom_option4, ['class' => 'form-control']) }}
												</fieldset>
											</div>
											@endif
										</div>
									@endif


									<div class="pull-right">
										{{ Form::submit(trans('common.save_changes'), ['class' => 'btn btn-success']) }}
									</div>
									<div class="clearfix"></div>
								</form>
							</div>
						</div>
					</div>
					<!-- End of first panel -->

{{--					<div class="panel panel-default">--}}
{{--						<div class="panel-heading no-bg panel-settings">--}}
{{--							<h3 class="panel-title">--}}
{{--								{{ trans('common.update_password') }}--}}
{{--							</h3>--}}
{{--						</div>--}}
{{--						<div class="panel-body nopadding">--}}
{{--							<div class="socialite-form">								--}}
{{--								<form method="POST" action="{{ url('/'.Auth::user()->username.'/settings/password/') }}">--}}
{{--									{{ csrf_field() }}--}}

{{--									<div class="row">--}}
{{--										<div class="col-md-6">--}}
{{--											<fieldset class="form-group {{ $errors->has('current_password') ? ' has-error' : '' }}">--}}
{{--												{{ Form::label('current_password', trans('common.current_password')) }}--}}
{{--												<input type="password" class="form-control" id="current_password" name="current_password" value="{{ old('current_password') }}" placeholder= "{{ trans('messages.enter_old_password') }}">--}}

{{--												@if ($errors->has('current_password'))--}}
{{--												<span class="help-block">--}}
{{--													{{ $errors->first('current_password') }}--}}
{{--												</span>--}}
{{--												@endif--}}
{{--											</fieldset>--}}
{{--										</div>--}}
{{--										<div class="col-md-6">--}}
{{--											<fieldset class="form-group {{ $errors->has('new_password') ? ' has-error' : '' }}">--}}
{{--												{{ Form::label('new_password', trans('common.new_password')) }}--}}
{{--												<input type="password" class="form-control" id="new_password" name="new_password" value="{{ old('new_password') }}" placeholder="{{ trans('messages.enter_new_password') }}">--}}

{{--												@if($errors->has('new_password'))--}}
{{--												<span class="help-block">--}}
{{--													{{ $errors->first('new_password') }}--}}
{{--												</span>--}}
{{--												@endif--}}
{{--											</fieldset>--}}
{{--										</div>--}}
{{--									</div>--}}

{{--									<div class="pull-right">--}}
{{--										{{ Form::submit(trans('common.save_password'), ['class' => 'btn btn-success']) }}--}}
{{--									</div>--}}
{{--									<div class="clearfix"></div>--}}
{{--								</form>--}}
{{--							</div>--}}
{{--						</div>--}}
{{--					</div>--}}
					<!-- End of second panel -->

				</div>
			</div><!-- /row -->
		</div>
	<!-- </div> --><!-- /main-content -->
