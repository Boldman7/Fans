<div class="conversation">
		<div class="left-side">
			bessie berry <span class="chat-status"></span>
		</div>
		<div class="right-side">
			<ul class="list-inline primary-list">
				<li>
					<ul class="pagination">
			    		<li>
					    	<a href="#">
					        	<i class="fa fa-pencil" aria-hidden="true"></i>
					      	</a>
			    		</li>
					    <li>
					    	<a href="#">
					    		<i class="fa fa-reply" aria-hidden="true"></i>
					    	</a>
					    </li>
					    <li>
					    	<a href="#">
					        	<i class="fa fa-trash" aria-hidden="true"></i>
					      	</a>
			    		</li>
			  		</ul>
				</li>
			</ul>
		</div>
	</div>
	<div class="clearfix"></div>
	<ul class="list-unstyled coversations-thread scrollable"> 
		<li class="message-conversation">
			<div class="media post-list ">
				<div class="media-left">
					<a href="#">
			    		<img src="{!! Theme::asset()->url('images/avatar-bessie.png') !!}" class="img-icon img-46" alt="">
			   		</a>
			  	</div>
		  		<div class="media-body ">
			    	<h4 class="media-heading"><a href="#">bessie berry</a><span class="text-muted">8:31AM</span></h4>
					<p class="post-text">
				    	Hi guys Ive got the O2 package and have really slow internet. A speed check online said i can get 3mbps but 
					</p>
		  		</div>
			</div>
		</li>
		<li class="message-conversation current-user">
			<div class="media post-list">
				<div class="media-left">
					<a href="#">
			    		<img src="{!! Theme::asset()->url('images/avatar.png"') !!} class="img-icon img-46" alt="">
			   		</a>
			  	</div>
			  	<div class="media-body ">
			    	<h4 class="media-heading"><a href="#">jordan jackson</a><span class="text-muted">8:32AM</span></h4>
					 <p class="post-text">
				    	I have internet for 9 month and nevere could benefit from the full capacity of 5Mbit/s as it is filtered by O2 
					</p>
			  	</div>
			</div>
		</li>
		<li>
			<div class="message-divider">
				<div class="day">
					tuesday
				</div>
			</div>
		</li>
		<li class="message-conversation">
			<div class="media post-list">
				<div class="media-left">
					<a href="#">
			    		<img src="{!! Theme::asset()->url('images/avatar-bessie.png') !!}" class="img-icon img-46" alt="">
			   		</a>
			  	</div>
			  	<div class="media-body ">
			    	<h4 class="media-heading"><a href="#">bessie berry</a><span class="text-muted">8:34AM</span></h4>
					<p class="post-text">
				    	Funny comparison. so would the proper antivirus not slow down the internet as much or do you mean a 
						freebie doenst protect the computer from viruses?
					</p>
				  </div>
			</div>
		</li>
		<li class="message-conversation">
			<div class="media post-list">
				<div class="media-left">
					<a href="#">
			    		<img src="{!! Theme::asset()->url('images/avatar.png"') !!} class="img-icon img-46" alt="">
			   		</a>
			  	</div>
			  	<div class="media-body ">
			    	<h4 class="media-heading"><a href="#">jordan jackson</a><span class="text-muted">8:39AM</span></h4>
					<p class="post-text">
				    	I pay for the 4Mb/sec down, 512 Kb/sec up service from O2, and haven't had any problems. In fact, it's relatively 
					</p>
			  	</div>
			</div>
			 <div class="post-pictures">
		    	<div class="row post-row">
					<div class="col-md-4 image-col">
						<div class="img-holder">
							<a href="#"><img src="{!! Theme::asset()->url('images/nature8.png') !!}" alt="images">
								<div class="img-search">
									<i class="fa fa-search-plus"></i>
								</div>
							</a>
						</div>
					</div>
					<div class="col-md-4 image-col">
						<div class="img-holder">
							<a href="#">
								<img src="{!! Theme::asset()->url('images/nature8.png') !!}" alt="images">
								<div class="img-search">
									<i class="fa fa-search-plus"></i>
								</div>
							</a>
						</div>
					</div>
					<div class="col-md-4 image-col">
						<div class="img-holder">
							<a href="#"><img src="{!! Theme::asset()->url('images/nature8.png') !!}" alt="images">
								<div class="img-search">
									<i class="fa fa-search-plus"></i>
								</div>
							</a>
						</div>
					</div>
		    	</div>
		    </div>
		</li>
		<li>
			<div class="message-divider blue">
				<div class="day">
					new messages
				</div>
			</div>
		</li>
		<li class="message-conversation">
			<div class="media post-list">
				<div class="media-left">
					<a href="#">
			    		<img src="{!! Theme::asset()->url('images/avatar-bessie.png') !!}" class="img-icon img-46" alt="">
			   		</a>
			  	</div>
			  	<div class="media-body ">
			    	<h4 class="media-heading"><a href="#">bessie berry</a><span class="text-muted">8:45AM</span></h4>
					<p class="post-text">
				    	Funny comparison. so would the proper antivirus not slow down the internet as much or do you mean a 
						freebie doenst protect the computer from viruses?
					</p>
			  	</div>
			</div>
		</li>
	</ul>