{!! Theme::partial('reply',compact('reply','post')) !!}
