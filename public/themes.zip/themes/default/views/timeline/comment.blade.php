{!! Theme::partial('comment',compact('comment','post')) !!}
