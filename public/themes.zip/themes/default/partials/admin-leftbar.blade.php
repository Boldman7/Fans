<div class="list-group list-group-navigation socialite-group">
    <a href="{{ url('/admin') }}" class="list-group-item">

        <div class="list-icon socialite-icon {{ (Request::segment(1) == 'admin' && Request::segment(2)==null) ? 'active' : '' }}">
            <i class="fa fa-dashboard"></i>
        </div>
        <div class="list-text">
            <span class="badge pull-right"></span>
            {{ trans('common.dashboard') }}
            <div class="text-muted">
                {{ trans('common.application_statistics') }}
            </div>
        </div>
        <span class="clearfix"></span>
    </a>
    <a href="{{ url('/admin/wallpapers') }}" class="list-group-item">
  
        <div class="list-icon socialite-icon {{ Request::segment(2) == 'wallpapers' ? 'active' : '' }}">
            <i class="fa fa-picture-o"></i>
        </div>
        <div class="list-text">
            <span class="badge pull-right"></span>
            {{ trans('common.wallpapers') }}
            <div class="text-muted">
                {{ trans('common.wallpapers_text') }}
            </div>
        </div>
        <span class="clearfix"></span>
    </a>

    <a href="{{ url('/admin/users') }}" class="list-group-item">

        <div class="list-icon socialite-icon {{ Request::segment(2) == 'users' ? 'active' : '' }}">
            <i class="fa fa-user-plus"></i>
        </div>
        <div class="list-text">
            <span class="badge pull-right"></span>
            {{ trans('common.manage_users') }}
            <div class="text-muted">
                {{ trans('common.manage_users_text') }}
            </div>
        </div>
        <span class="clearfix"></span>
    </a>

    <a href="{{ url('/admin/manage-reports') }}" class="list-group-item">

        <div class="list-icon socialite-icon {{ Request::segment(2) == 'manage-reports' ? 'active' : '' }}">
            <i class="fa fa-bug"></i>
        </div>
        
        <div class="list-text">
            @if(Auth::user()->getReportsCount() > 0)
            <span class="badge pull-right">{{ Auth::user()->getReportsCount() }}</span>
            @endif            
            {{ trans('common.manage_reports') }}
            <div class="text-muted">
                {{ trans('common.manage_reports_text') }}
            </div>             
        </div>
        <span class="clearfix"></span>
    </a>
</div>



